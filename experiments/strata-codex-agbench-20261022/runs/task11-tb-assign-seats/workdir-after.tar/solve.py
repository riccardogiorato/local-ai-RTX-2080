import base64, itertools, pickletools

P = ['Alice', 'Bob', 'Charlie', 'David', 'Ethan', 'Frankie']

def safe_strings(path):
    # Read pickle payloads without executing code: pull string constants
    # straight out of the opcode stream, and refuse anything executable.
    out, unsafe = [], False
    for opcode, arg, _ in pickletools.genops(open(path, 'rb')):
        if opcode.name in ('SHORT_BINUNICODE', 'BINUNICODE', 'BINUNICODE8'):
            out.append(arg)
        elif opcode.name in ('GLOBAL', 'REDUCE', 'STACK_GLOBAL', 'BUILTIN'):
            unsafe = True
    if unsafe:
        raise SystemExit(f'{path}: executable pickle opcodes, refusing to decode')
    return out

for f in ('protected/ask_alice.pkl', 'protected/ask_bob.pkl'):
    for s in safe_strings(f):
        print(f'[pkl] {s}')
print(f"[b64] {base64.b64decode(open('protected/ask_charlie.b64').read().strip()).decode()}")
for f in ('clue.txt', 'frankie_preferences.txt', 'random_fact.txt'):
    print(f'[txt] ' + open('protected/' + f).read().strip())

N = 6
adj = lambda a, b: (a - b) % N in (1, N - 1)
across = lambda a, b: (a - b) % N == 3

def valid(pos):        # seat indices run clockwise, so seat+1 is to the right
    A, B, D, E, F = pos['Alice'], pos['Bob'], pos['David'], pos['Ethan'], pos['Frankie']
    if B != (A - 2) % N: return False                       # Bob: two seats left of Alice
    if adj(B, E): return False                              # Bob refuses to sit next to Ethan
    if across(E, B) and D != (A + 2) % N: return False      # clue.txt
    if adj(A, F): return False                              # Alice & Frankie: rival companies
    if not (adj(F, D) or adj(F, E)): return False           # Frankie next to David or Ethan
    return True

def mir_class(rot):
    # rot has Charlie at index 0; mirror flips the other seats
    return min(rot, (rot[0],) + tuple(rot[N - i] for i in range(1, N)))

pairs, classes = set(), set()
for perm in itertools.permutations(range(N)):
    pos = dict(zip(P, perm))
    if valid(pos):
        name_of = {v: k for k, v in pos.items()}
        c = pos['Charlie']
        pairs.add(tuple(sorted([name_of[(c - 1) % N], name_of[(c + 1) % N]])))
        classes.add(mir_class(tuple(name_of[(i + c) % N] for i in range(N))))

print(f'\n{len(classes)} seating(s) up to rotation + mirror:')
for cl in sorted(classes): print('  ' + ' '.join(cl))
lines = [', '.join(p) for p in sorted(pairs)]
print('\nCharlie neighbour pairs: ' + '; '.join(lines))
open('results.txt', 'w').write('\n'.join(lines) + '\n')
