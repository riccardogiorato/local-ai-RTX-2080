#!/usr/bin/env python3
"""Filter data/bank_transactions.csv down to one company's transactions.

The company is identified jointly by name variants (typo tolerant, including
the acronym/abbreviation form) and by its account number (typo tolerant).
A row belongs to the company when *either* signal matches.
"""

import csv
import json
from collections import Counter

INPUT = "data/bank_transactions.csv"
OUTPUT = "data/output.json"

TARGET_NAME = "North West Capital Group Incorporated"
TARGET_ACRONYM = "nwcg"  # initials of "North West Capital Group"
KEY_TOKENS = ["north", "west", "capital", "group"]
SUFFIX_TOKEN = "incorporated"
MAX_TOKEN_DIST = 1
MAX_SUFFIX_DIST = 2
MAX_ACCOUNT_DIST = 2

COLUMNS = ["Company Name", "Account Number", "Date", "Amount",
           "Transaction Type", "Description"]


def edit_distance(a, b):
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[len(b)]


def tokens(name):
    out, tok = [], []
    for ch in name.lower():
        if ch.isalnum():
            tok.append(ch)
        elif tok:
            out.append("".join(tok))
            tok = []
    if tok:
        out.append("".join(tok))
    return out


def name_matches(name):
    toks = tokens(name)
    # full-name variant: the four identity tokens aligned, plus a corporate suffix
    if len(toks) >= len(KEY_TOKENS) + 1:
        aligned = all(edit_distance(t, k) <= MAX_TOKEN_DIST
                      for t, k in zip(toks[:len(KEY_TOKENS)], KEY_TOKENS))
        suffix = any(edit_distance(t, SUFFIX_TOKEN) <= MAX_SUFFIX_DIST
                     for t in toks[len(KEY_TOKENS):])
        if aligned and suffix:
            return True
    # abbreviation variant, e.g. "NWCG Inc. Pty. Ltd."
    return any(len(t) >= len(TARGET_ACRONYM)
               and edit_distance(t, TARGET_ACRONYM) <= MAX_TOKEN_DIST for t in toks)


def main():
    with open(INPUT, newline="") as f:
        rows = list(csv.DictReader(f))

    seeds = [r for r in rows if name_matches(r["Company Name"])]
    canonical_account = Counter(r["Account Number"] for r in seeds).most_common(1)[0][0]

    picked = [r for r in rows
              if name_matches(r["Company Name"])
              or edit_distance(r["Account Number"], canonical_account) <= MAX_ACCOUNT_DIST]
    picked.sort(key=lambda r: r["Date"])

    payload = [{c: r[c] for c in COLUMNS} for r in picked]
    with open(OUTPUT, "w") as f:
        json.dump(payload, f, indent=2)
        f.write("\n")

    print(f"canonical account: {canonical_account}")
    print("name variants kept:", sorted(set(r["Company Name"] for r in picked)))
    print("account variants kept:", sorted(set(r["Account Number"] for r in picked)))
    print(f"rows kept: {len(picked)} of {len(rows)}")


if __name__ == "__main__":
    main()
