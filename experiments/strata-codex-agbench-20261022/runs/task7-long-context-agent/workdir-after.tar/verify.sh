#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
node test/gateway.test.js
