// Quota gateway, per ADR-0042 (docs/ADR-0014.md): every response carries
// `X-Rate-Limit` as a decimal string; when quota is exhausted the module
// returns 429 with `Retry-After: 30` (ADR-0027 supersedes ADR-0019).
const EXHAUSTED_STATUS = 429;
const RETRY_AFTER = '30';

function respond(status, quotaRemaining) {
    const headers = { 'X-Rate-Limit': String(quotaRemaining) };
    if (quotaRemaining <= 0) {
        headers['Retry-After'] = RETRY_AFTER;
        return { status: EXHAUSTED_STATUS, headers };
    }
    return { status, headers };
}
module.exports = { respond };
