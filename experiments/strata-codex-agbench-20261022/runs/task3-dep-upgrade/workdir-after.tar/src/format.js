import { formatDistance } from "date-fns";

// Wraps date-fns for the app, now on date-fns v4.
// formatDistance is unchanged by the v4 API churn (v4 renamed maxDate/minDate
// to max/min and dropped the locale formatLong formatters; neither is used
// here), and addSuffix behaves as before. Invalid input, e.g. "not-a-date",
// throws RangeError from date-fns itself, so no extra validation is needed.
export function postedAt(dateLike) {
  return formatDistance(new Date(dateLike), new Date(), { addSuffix: true });
}
