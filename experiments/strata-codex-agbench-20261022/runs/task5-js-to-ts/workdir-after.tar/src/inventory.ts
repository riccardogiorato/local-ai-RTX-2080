// Product inventory helpers — routinely used across the app.

export interface Item {
  sku: string;
  name: string;
  qty: number;
}

export function stockValue(items: Item[], priceOf: (sku: string) => number): number {
  let total = 0;
  for (const it of items) {
    total += it.qty * priceOf(it.sku);
  }
  return total;
}

export function lowStock(items: Item[], threshold: number = 5): string[] {
  return items
    .filter((it) => it.qty <= threshold)
    .map((it) => it.sku)
    .sort();
}

export function restockReport(items: Item[], wanted: Record<string, number>): string {
  // wanted: { sku -> qty to buy }
  const lines: string[] = [];
  for (const sku of Object.keys(wanted)) {
    const item = items.find((it) => it.sku === sku);
    const name = item ? item.name : "unknown";
    lines.push(`${name}: +${wanted[sku]}`);
  }
  return lines.join("\n");
}
