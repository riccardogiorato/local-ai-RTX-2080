import React from "react";

// Renders a pricing table. The API contract (see verify.sh) expects:
//  - a <table> with exactly one <thead> row of column headers: Item, Qty, Price
//  - one <tbody> row per item, <td> children in the same order
//  - prices formatted as "12.50" (two decimals, dot separator) with the
//    currency symbol AFTER the amount: "12.50 EUR"
//  - the grand total line rendered as a <tfoot> row reading
//    "Total: 17.50 EUR" (sum of qty * price)
export function PricingTable({ items, currency = "EUR" }) {
  function fmt(n) {
    return `${n.toFixed(2)} ${currency}`;
  }

  const total = items.reduce((acc, it) => acc + it.qty * it.price, 0);

  return (
    <table className="pricing">
      <thead>
        <tr>
          <th>Item</th>
          <th>Qty</th>
          <th>Price</th>
        </tr>
      </thead>
      <tbody>
        {items.map((it) => (
          <tr key={it.name}>
            <td>{it.name}</td>
            <td>{it.qty}</td>
            <td>{fmt(it.qty * it.price)}</td>
          </tr>
        ))}
      </tbody>
      <tfoot>
        <tr>
          <td colSpan={3}>{`Total: ${fmt(total)}`}</td>
        </tr>
      </tfoot>
    </table>
  );
}
