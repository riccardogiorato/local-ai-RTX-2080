#!/usr/bin/env python3
"""Summarize an Apache/nginx combined-format access log into report.txt."""
import re
from collections import Counter
from pathlib import Path

LINE = re.compile(
    r'^(?P<ip>\S+) \S+ \S+ \[(?P<time>[^\]]*)\] '
    r'"(?P<method>\S+) (?P<url>\S+) (?P<proto>[^"]*)"'
    r' (?P<status>\d{3}) (?P<bytes>\S+)$'
)


def parse(path):
    requests = []
    skipped = 0
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            if not line.strip():
                continue
            match = LINE.match(line)
            if match:
                requests.append(match.groupdict())
            else:
                skipped += 1
    return requests, skipped


def main():
    log = Path(__file__).resolve().parent / "access_log"
    requests, skipped = parse(log)

    url_counts = Counter(req["url"] for req in requests)
    top = sorted(url_counts.items(), key=lambda item: (-item[1], item[0]))[:3]

    lines = [
        f"Total requests: {len(requests)}",
        f"Unique IP addresses: {len({req['ip'] for req in requests})}",
        "Top 3 URLs:",
    ]
    lines.extend(f"  {url}: {count}" for url, count in top)
    lines.append(f"404 errors: {sum(1 for req in requests if req['status'] == '404')}")

    (Path(__file__).resolve().parent / "report.txt").write_text("\n".join(lines) + "\n")
    if skipped:
        print(f"note: {skipped} malformed lines ignored", file=__import__("sys").stderr)


if __name__ == "__main__":
    main()
