import { formatDistance } from "date-fns";

// Wraps date-fns for the app. Now on v4 (4.4.0). The v2-era renames
// (`distanceInWords` -> `formatDistance`, string `locale` -> locale object) are
// already satisfied by this file, and v3/v4 changed packaging, types and
// internals rather than this API: v2.30 and v4.4.0 return identical strings,
// and invalid input still throws RangeError. Nothing to rename here.
export function postedAt(dateLike) {
  return formatDistance(new Date(dateLike), new Date(), { addSuffix: true });
}