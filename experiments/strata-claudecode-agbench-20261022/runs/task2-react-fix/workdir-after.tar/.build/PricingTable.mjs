import { jsx, jsxs } from "react/jsx-runtime";
import React from "react";
function PricingTable({ items, currency = "EUR" }) {
  function fmt(n) {
    return n.toFixed(2) + " " + currency;
  }
  const lineTotal = (it) => it.qty * it.price;
  const total = items.reduce((acc, it) => acc + lineTotal(it), 0);
  return /* @__PURE__ */ jsxs("table", { className: "pricing", children: [
    /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [
      /* @__PURE__ */ jsx("th", { children: "Item" }),
      /* @__PURE__ */ jsx("th", { children: "Qty" }),
      /* @__PURE__ */ jsx("th", { children: "Price" })
    ] }) }),
    /* @__PURE__ */ jsx("tbody", { children: items.map((it) => /* @__PURE__ */ jsxs("tr", { children: [
      /* @__PURE__ */ jsx("td", { children: it.name }),
      /* @__PURE__ */ jsx("td", { children: it.qty }),
      /* @__PURE__ */ jsx("td", { children: fmt(lineTotal(it)) })
    ] }, it.name)) }),
    /* @__PURE__ */ jsx("tfoot", { children: /* @__PURE__ */ jsx("tr", { children: /* @__PURE__ */ jsx("td", { colSpan: 3, children: "Total: " + fmt(total) }) }) })
  ] });
}
var stdin_default = PricingTable;
export {
  PricingTable,
  stdin_default as default
};
