import React from "react";

// Renders a pricing table. The API contract (enforced by render-check.mjs) expects:
//  - a <table> with exactly one <thead> row of column headers: Item, Qty, Price
//  - one <tbody> row per item, <td> children in the same order, in input order
//  - each row's Price cell is the line total (qty * price), formatted as
//    "12.00 EUR": two decimals, dot separator, currency AFTER the amount.
//    The amount and currency must be a single string in one cell: React 19 SSR
//    separates adjacent text children with "<!-- -->", which breaks the contract.
//  - the grand total line rendered as a <tfoot> row reading "Total: 17.50 EUR".
export function PricingTable({ items, currency = "EUR" }) {
  function fmt(n) {
    return n.toFixed(2) + " " + currency;
  }

  const lineTotal = (it) => it.qty * it.price;
  const total = items.reduce((acc, it) => acc + lineTotal(it), 0);

  return (
    <table className="pricing">
      <thead>
        <tr>
          <th>Item</th>
          <th>Qty</th>
          <th>Price</th>
        </tr>
      </thead>
      <tbody>
        {items.map((it) => (
          <tr key={it.name}>
            <td>{it.name}</td>
            <td>{it.qty}</td>
            <td>{fmt(lineTotal(it))}</td>
          </tr>
        ))}
      </tbody>
      <tfoot>
        <tr>
          <td colSpan={3}>{"Total: " + fmt(total)}</td>
        </tr>
      </tfoot>
    </table>
  );
}

export default PricingTable;
