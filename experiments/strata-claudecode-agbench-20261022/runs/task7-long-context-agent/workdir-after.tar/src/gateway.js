// Simple quota gateway, per ADR-0042 (docs/ADR-0014.md).
function respond(status, quotaRemaining) {
    if (quotaRemaining <= 0) {
        // Quota exhausted: HTTP 429, remaining quota reads as 0, and the
        // client is told when it may retry.
        return { status: 429, headers: { 'X-Rate-Limit': '0', 'Retry-After': '30' } };
    }
    return { status, headers: { 'X-Rate-Limit': String(quotaRemaining) } };
}
module.exports = { respond };
